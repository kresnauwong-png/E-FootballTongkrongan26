const express = require("express");
const sqlite3 = require("sqlite3").verbose();
const bodyParser = require("body-parser");

const app = express();
app.use(express.static(__dirname));
app.use(bodyParser.json());

const db = new sqlite3.Database("database.db");

db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nama TEXT,
    email TEXT
)`);

app.post("/simpan", (req, res) => {
    const { nama, email } = req.body;
    db.run("INSERT INTO users (nama, email) VALUES (?, ?)", [nama, email]);
    res.send("ok");
});

app.get("/data", (req, res) => {
    db.all("SELECT * FROM users", [], (err, rows) => {
        res.json(rows);
    });
});

app.listen(3000, () => console.log("http://localhost:3000"));
