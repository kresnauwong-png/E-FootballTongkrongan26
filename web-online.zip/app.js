function kirim() {
    fetch("/simpan", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({
            nama: document.getElementById("nama").value,
            email: document.getElementById("email").value
        })
    }).then(() => tampil());
}

function tampil() {
    fetch("/data")
    .then(res => res.json())
    .then(data => {
        let list = document.getElementById("list");
        list.innerHTML = "";
        data.forEach(d => {
            list.innerHTML += `<li>${d.nama} - ${d.email}</li>`;
        });
    });
}

tampil();
